CREATE TABLE title_ratings ( 
	tconst VARCHAR(1000) PRIMARY KEY,
	averageRating FLOAT,
	numVotes INTEGER
)

