CREATE TABLE title_akas (
	titleId VARCHAR(1000),
	ordering INTEGER,
	title TEXT,
	region VARCHAR(64),
	language VARCHAR(64),
	types TEXT,
	attributes TEXT,
	isOriginalTitle BOOLEAN
)


