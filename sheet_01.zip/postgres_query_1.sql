select *
from pg_config
where name = 'VERSION';
