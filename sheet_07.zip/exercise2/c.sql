SELECT staff.first_name, staff.last_name,(
	SELECT MAX(avg_payment_from_customer) 
	FROM (
		SELECT AVG(payment.amount) AS avg_payment_from_customer 
		FROM payment WHERE payment.staff_id = staff.staff_id
		GROUP BY payment.customer_id) AS vector 
) AS highest_avg_payment_from_customer
FROM staff
ORDER BY highest_avg_payment_from_customer ASC, last_name;