SELECT film.title, total_payment
FROM film 
LEFT JOIN (
	SELECT film.film_id AS fid, SUM(payment.amount) AS total_payment
	FROM film 
	INNER JOIN inventory ON film.film_id = inventory.film_id
	INNER JOIN rental ON rental.inventory_id = inventory.inventory_id
	INNER JOIN payment ON payment.rental_id = rental.rental_id
	GROUP BY film.film_id) vector
ON film.film_id = fid
ORDER BY total_payment ASC, film.title;
