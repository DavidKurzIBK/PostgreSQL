WITH t AS(
	SELECT film.film_id AS film_id, 
	category.category_id AS category_id, 
	film.title AS film_title,
	payment.amount AS payment_amount,
	category.name AS category_name 
	FROM category
	INNER JOIN film_category ON film_category.category_id = category.category_id
	INNER JOIN film ON film.film_id = film_category.film_id
	INNER JOIN inventory ON film.film_id = inventory.film_id
	INNER JOIN rental ON rental.inventory_id = inventory.inventory_id 
	INNER JOIN payment ON payment.rental_id = rental.rental_id)
	SELECT * FROM (
		SELECT t.film_title AS title,
		t.category_name AS category_name,
		SUM(t.payment_amount) AS total_earnings,
		AVG(t.payment_amount) AS average_payment
		FROM t GROUP BY t.film_id,
		t.film_title, 
		t.category_name
		UNION ALL 
		SELECT 'Category Pricings' AS title,
		t.category_name AS category_name,
		SUM(t.payment_amount) AS total_earnings,
		AVG(t.payment_amount) AS average_payment
		FROM t 
		GROUP BY t.category_id, category_name) vector
		ORDER BY total_earnings DESC, title, category_name;