SELECT film.title, film.length, SUM(payment.amount) AS total_payment 
FROM film
INNER JOIN inventory ON film.film_id = inventory.film_id
INNER JOIN rental ON rental.inventory_id = inventory.inventory_id
INNER JOIN payment ON payment.rental_id = rental.rental_id
GROUP BY film.film_id, film.title HAVING SUM(payment.amount) > 180
ORDER BY total_payment DESC;