SELECT category.name AS category_name, AVG(film.rental_duration) AS avg_rental_duration
FROM film
INNER JOIN film_category ON film.film_id = film_category.film_id
INNER JOIN category ON film_category.category_id = category.category_id
GROUP BY category.category_id, category.name
ORDER BY avg_rental_duration ASC;