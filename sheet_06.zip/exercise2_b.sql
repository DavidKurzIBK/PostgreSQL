--select * from film
--select * from category



SELECT title, category.name AS category
FROM film
INNER JOIN film_category ON film.film_id = film_category.film_id
INNER JOIN category ON film_category.category_id = category.category_id
WHERE category.name IN ('Documentary', 'Comedy') AND film.replacement_cost < 10.00; 

-- WHERE (category.name = 'Documentary' or category.name = 'Comedy')



