--select * from customer 
--select * from payment
--select * from staff
--select * from  

SELECT customer.first_name || ' ' || customer.last_name AS customer_name, staff.first_name || ' ' || staff.last_name AS staff_name, SUM(amount) AS total_amount
FROM payment
JOIN customer USING(customer_id) 
JOIN staff USING(staff_id) 
GROUP BY customer_id, staff_id 
ORDER BY total_amount DESC FETCH FIRST 1 ROWS ONLY;
