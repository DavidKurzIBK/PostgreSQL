--select * from customer 
--select * from address
--select * from city
--select * from country 

SELECT concat(first_name, ' ', last_name) AS name
FROM customer
INNER JOIN address ON customer.address_id = address.address_id
INNER  JOIN city ON address.city_id = city.city_id
INNER JOIN country ON city.country_id = country.country_id WHERE country.country LIKE '%land';
