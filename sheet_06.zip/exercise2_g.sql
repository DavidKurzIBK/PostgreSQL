--select * from film

SELECT COUNT(DISTINCT film.rating) AS differen_ratings
FROM film 
WHERE 'Deleted Scenes' = ANY(special_features);
