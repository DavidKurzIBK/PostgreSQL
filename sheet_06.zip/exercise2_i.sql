
--select * from language
--select * from film

SELECT language.name
FROM language
LEFT JOIN film ON language.language_id = film.language_id
WHERE film.film_id IS NULL
ORDER BY language.name;
