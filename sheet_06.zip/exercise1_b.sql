-- Erstellen der Tabelle 'employee'
CREATE TABLE employee (
    employee_id SERIAL PRIMARY KEY,
    firstname VARCHAR(255),
    lastname VARCHAR(255),
    main_location VARCHAR(255)
);

-- Erstellen der Tabelle 'project'
CREATE TABLE project (
    project_id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    main_location VARCHAR(255)
);

-- Erstellen der Tabelle 'working' mit Fremdschlüssel-Referenzen
CREATE TABLE working (
    employee_id INTEGER REFERENCES employee(employee_id),
    project_id INTEGER REFERENCES project(project_id),
    start_date TIMESTAMP, -- oder DATE
    PRIMARY KEY (employee_id, project_id) -- oder CONSTRAINT pk_working PRIMARY KEY(employee_id, project_id)
);
