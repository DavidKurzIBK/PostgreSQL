--select * from film
--select * from actor

SELECT film.title, film.length
FROM film
JOIN film_actor ON film.film_id = film_actor.film_id
JOIN actor ON film_actor.actor_id = actor.actor_id
WHERE actor.first_name = 'AUDREY';

/*
SELECT DISTINCT title, length
FROM actor
INNER JOIN film_actor
ON actor.actor_id = film_actor.actor_id
INNER JOIN film
ON flim_actor.film_id = film.film_id
WHERE actor.first_name = 'AUDREY';*/

