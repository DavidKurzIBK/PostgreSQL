--select * from customer 
--select * from rental
--select * from staff

SELECT customer.last_name, rental.return_date FROM customer
INNER JOIN rental ON customer.customer_id = rental.customer_id
INNER JOIN staff ON rental.staff_id = staff.staff_id WHERE staff.last_name = 'Stephens' AND DATE(rental.rental_date) = '2005-05-24';
