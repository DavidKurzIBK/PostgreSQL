--select * from rental
 
SELECT COUNT(*) AS renturned_friday_13
FROM rental 
WHERE EXTRACT(ISODOW FROM rental.return_date) = 5
AND EXTRACT(DAY FROM rental.return_date) = 13;