

SELECT customer_id, last_name, first_name FROM customer
ORDER BY last_name ASC;